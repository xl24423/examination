package cn.xl.examination;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExaminationApplicationTests {

    @Test
    void contextLoads() {
    }

}
