package cn.xl.examination.service;

import com.baomidou.mybatisplus.extension.service.IService;
import cn.xl.examination.entity.OperationTicket;

/**
 * (OperationTicket)表服务接口
 *
 * @author makejava
 * @since 2022-07-13 10:55:57
 */
public interface OperationTicketService extends IService<OperationTicket> {

}

