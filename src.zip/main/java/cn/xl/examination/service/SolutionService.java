package cn.xl.examination.service;

import com.baomidou.mybatisplus.extension.service.IService;
import cn.xl.examination.entity.Solution;

/**
 * (Solution)表服务接口
 *
 * @author makejava
 * @since 2022-07-13 10:55:58
 */
public interface SolutionService extends IService<Solution> {

}

